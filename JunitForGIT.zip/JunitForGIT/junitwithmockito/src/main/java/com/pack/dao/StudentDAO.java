package com.pack.dao;

import com.pack.beans.Student;

public class StudentDAO {

	public int getMarks(Integer id) {
		// may be it is connected with a database table
		// get id's corrosponding student object
		// return his/her total marks
		
		return 120;
	}

	public void saveRecord(Student s) {
		// may be it is connected with a database table
		// save the record in student table
		
	}

	public Student findById(int id) {
		// may be it is connected with a database table
		// get id's corrosponding student object
		// return that object
		return null;
	}

}
