package com.pack.service;

import com.pack.beans.Student;
import com.pack.dao.StudentDAO;

public class StudentService {
	private StudentDAO sDao;
	
	public void setsDao(StudentDAO sDao) {
		this.sDao = sDao;
	}

	public String computeGrade(Student s) {
		int marks=sDao.getMarks(s.getId());
		String grade="";
		if(marks>=95)
			grade="A+";
		else if(marks>=85)
			grade="A";
		else if(marks>=70)
			grade="B";
		else if(marks<70)
			grade="F";
		
		s.setGrade(grade);	
		
		return grade;				
	}
	
	public boolean saveRecord(Student s) {
		if(s.getName().length()>=2) {
			sDao.saveRecord(s);
			return true;
		}
		else
			return false;			
	}
	
	public Student getStudent(int id) {
		Student s=sDao.findById(id);
		return s;
	}
	
}









