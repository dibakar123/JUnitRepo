package com.pack.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.pack.beans.Student;
import com.pack.dao.StudentDAO;

public class StudentServiceTest {
	
	@Mock
	StudentDAO sDao;
	
	@InjectMocks
	StudentService service;
	
	@Before
	public void before() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(expected=NullPointerException.class)
	public void test6() {
		doThrow(NullPointerException.class).when(sDao).findById(454);
		assertNull(service.getStudent(454));
	}
	
	@Test
	public void test5() {
		when(sDao.findById(4)).thenReturn(new Student(4,"Param"));
		assertEquals("Param",service.getStudent(4).getName());
	}
	
	
	
	@Test
	public void test4() {
		Student s=new Student();
		s.setId(18);
		s.setName("Abdullah");
		when(sDao.getMarks(s.getId())).thenReturn(63);
		assertEquals("F",service.computeGrade(s));
		verify(sDao,times(1)).getMarks(s.getId());
	}
	

	@Test
	public void test3() {
		Student s=new Student();
		s.setId(18);
		s.setName("Abdullah");
		when(sDao.getMarks(s.getId())).thenReturn(98);
		assertEquals("A+",service.computeGrade(s));
		verify(sDao,times(1)).getMarks(s.getId());
	}
	
	
	@Test
	public void test2() {
		Student s=new Student();
		s.setId(18);
		s.setName("Abdullah");
		when(sDao.getMarks(s.getId())).thenReturn(93);
		assertEquals("A",service.computeGrade(s));
		verify(sDao,times(1)).getMarks(s.getId());
	}
	
	@Test
	public void test1() {
		Student s=new Student();
		s.setId(101);
		s.setName("Arjun");
	   when(sDao.getMarks(s.getId())).thenReturn(82);		
	   assertEquals("B",service.computeGrade(s));	
	   verify(sDao,times(1)).getMarks(s.getId());
	}
}








