package com.pack3;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculatorTest {
    @Test
	public void divisionBothNonZeroTest() {
    	Calculator calc = new Calculator();
    	int result = calc.division(12,2);
    	assertEquals("Test Passed",6,result);
		
	}
    
    @Test(expected = ArithmeticException.class)
	public void divisionWithSecondParamZeroTest() {
    	Calculator calc = new Calculator();
    	int result = calc.division(12,0);
    }
    
    @Test(expected = ArithmeticException.class)
   	public void divisionWithBothZeroTest() {
       	Calculator calc = new Calculator();
       	int result = calc.division(12,0);
       }
}
