package com.pack3;

public class Calculator {
	
	public int division(int a, int b) throws ArithmeticException{
		if(b!=0)
		return a/b;
		else
			throw new ArithmeticException();
	}

}
