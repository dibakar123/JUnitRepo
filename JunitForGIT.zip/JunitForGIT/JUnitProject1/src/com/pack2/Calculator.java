package com.pack2;

public class Calculator {
	
	public int multiply ( int a , int b) {
		return a*b;
	}

}
