package com.pack2;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class EvenOddTest {
    @Test
	public void isEvenSuccessTest() {
		EvenOdd object = new EvenOdd();
		boolean actual = object.isEven(12);
		assertTrue("Test passed " , actual);
		
	}
	@Test
    public void isEvenFailTest() {
    	EvenOdd object = new EvenOdd();
		boolean actual = object.isEven(13);
		assertFalse("Test passed " , actual);
		
	}
}
