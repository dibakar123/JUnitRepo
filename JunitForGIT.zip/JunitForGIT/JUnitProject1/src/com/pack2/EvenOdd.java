package com.pack2;

public class EvenOdd {

	public boolean isEven(int d) {
		return (d%2==0);
	}
}
