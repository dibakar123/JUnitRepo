package com.pack2;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class CalculatorTest {
	
	Calculator cal = null;
	
    @Before
	public void start() {
		System.out.println("JUNIT test start:::::");
		cal = new Calculator();
	}
    @After
	public void end() {
		System.out.println("JUNIT test end:::::");
		cal = null;
	}
	@Test
	public void calculateWithBothNonZeroTest(){
		int actual = cal.multiply(12,3);
		assertEquals("Test Success ", 36, actual);
		
		
	}
	
}
