package com.pack1;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class CalculatorTest {
	
	Calculator cal = null;
	
    @Before
	public void start() {
		System.out.println("JUNIT test start:::::");
		cal = new Calculator();
	}
    @After
	public void end() {
		System.out.println("JUNIT test end:::::");
		cal = null;
	}
	@Test
	public void calculateWithBothNonZeroTest(){
		int actual = cal.multiply(12,3);
		assertEquals("Test Success ", 36, actual);
		
		
	}
	@Test
	@Ignore
	public void calculateWithBothZeroTest(){
		int actual = cal.multiply(0,3);
		assertEquals("Test Success ", 10, actual);
		
		
	}
	@Test
	public void calculateWithOneZeroTest(){
		int actual = cal.multiply(12,0);
		assertEquals("Test Success ", 0, actual);
		
		
	}
}
